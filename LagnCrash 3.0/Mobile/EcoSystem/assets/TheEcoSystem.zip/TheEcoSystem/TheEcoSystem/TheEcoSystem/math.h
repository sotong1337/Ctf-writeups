//
//  math.h
//  The EcoSystem
//
//  Created by Carl Ian Voller on 5/10/2022.
//

#ifndef math_h
#define math_h

extern int math(const char *, char *);

#endif /* math_h */
