//
//  magic.h
//  The EcoSystem
//
//  Created by Carl Ian Voller on 5/10/2022.
//

#ifndef magic_h
#define magic_h

extern int magic(const char *, char *);

#endif /* magic_h */
