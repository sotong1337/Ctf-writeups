# The EcoSystem
This Project was modified from a template created by Apple. This template can be found here:
https://developer.apple.com/documentation/foundation/task_management/continuing_user_activities_with_handoff
